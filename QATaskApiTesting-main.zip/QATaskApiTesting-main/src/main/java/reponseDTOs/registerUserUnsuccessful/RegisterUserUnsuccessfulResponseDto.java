package reponseDTOs.registerUserUnsuccessful;

import lombok.Data;

@Data
public class RegisterUserUnsuccessfulResponseDto {

    private String error;
}
