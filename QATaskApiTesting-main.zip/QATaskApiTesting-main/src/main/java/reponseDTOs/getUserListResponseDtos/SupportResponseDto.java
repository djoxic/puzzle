package reponseDTOs.getUserListResponseDtos;


import lombok.Data;

@Data
public class SupportResponseDto {

    private String url;
    private String text;
}
