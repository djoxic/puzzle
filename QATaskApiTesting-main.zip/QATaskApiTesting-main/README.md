# QATaskApiTesting

# Build and Test
Run Tests using maven command: mvn clean test -Dsurefire.suiteXmlFiles=src/main/resources/testng.xml
